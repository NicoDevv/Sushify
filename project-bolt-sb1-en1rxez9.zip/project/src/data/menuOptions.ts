import { MenuOption } from '../types';

export const menuOptions: MenuOption[] = [
  {
    id: 'allyoucaneat-regular',
    name: 'All You Can Eat',
    description: 'Unlimited sushi experience with our premium selection',
    price: 29.99,
    image: 'https://images.pexels.com/photos/2098085/pexels-photo-2098085.jpeg',
    features: [
      'Unlimited orders for 2 hours',
      'Full access to regular menu',
      'Fresh ingredients daily',
      'Includes miso soup'
    ]
  },
  {
    id: 'allyoucaneat-festive',
    name: 'Festive All You Can Eat',
    description: 'Special festive selection with premium ingredients',
    price: 39.99,
    image: 'https://images.pexels.com/photos/2323398/pexels-photo-2323398.jpeg',
    features: [
      'Unlimited orders for 2.5 hours',
      'Access to special festive items',
      'Premium sake included',
      'Special dessert selection'
    ]
  },
  {
    id: 'alacarte-regular',
    name: 'À La Carte',
    description: 'Choose from our carefully curated menu',
    price: 0,
    image: 'https://images.pexels.com/photos/2098143/pexels-photo-2098143.jpeg',
    features: [
      'Pay per item',
      'No time limit',
      'Customizable portions',
      'Take-away available'
    ]
  },
  {
    id: 'alacarte-festive',
    name: 'Festive À La Carte',
    description: 'Premium selection for special occasions',
    price: 0,
    image: 'https://images.pexels.com/photos/3338499/pexels-photo-3338499.jpeg',
    features: [
      'Special festive dishes',
      'Premium ingredients',
      'Exclusive chef specials',
      'Seasonal selections'
    ]
  }
];