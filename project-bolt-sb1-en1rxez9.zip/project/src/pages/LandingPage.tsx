import React from 'react';
import { useNavigate } from 'react-router-dom';
import { menuOptions } from '../data/menuOptions';
import { Brush as Sushi } from 'lucide-react';
import JapanesePattern from '../components/JapanesePattern';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-red-50 relative overflow-hidden">
      <JapanesePattern className="top-0 left-0 opacity-10" />
      
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-4">
            <Sushi className="text-red-800 mr-2" size={40} />
            <h1 className="text-4xl md:text-5xl font-bold text-red-900">
              Sushify
            </h1>
          </div>
          <p className="text-xl text-gray-700 max-w-2xl mx-auto">
            Experience authentic Japanese cuisine with our carefully curated menu options
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {menuOptions.map((option) => (
            <div
              key={option.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:scale-105"
            >
              <div className="h-48 overflow-hidden">
                <img
                  src={option.image}
                  alt={option.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold text-red-900 mb-2">
                  {option.name}
                </h3>
                <p className="text-gray-600 mb-4">{option.description}</p>
                
                <div className="mb-6">
                  <ul className="space-y-2">
                    {option.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-gray-700">
                        <span className="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xl font-bold text-red-800">
                    {option.price > 0 ? `$${option.price}` : 'Pay per item'}
                  </span>
                  <button
                    onClick={() => navigate(`/menu?type=${option.id}`)}
                    className="px-6 py-2 bg-red-800 text-white rounded-full hover:bg-red-700 transition-colors"
                  >
                    View Menu
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LandingPage;